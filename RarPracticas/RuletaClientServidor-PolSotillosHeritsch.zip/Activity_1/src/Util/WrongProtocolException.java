package Util;

@SuppressWarnings("serial")
public class WrongProtocolException extends Exception {

	public WrongProtocolException(String err) {
		super(err);
	}
}
